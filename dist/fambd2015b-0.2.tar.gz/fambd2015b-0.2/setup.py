from setuptools import setup

setup(name='fambd2015b',
      version='0.2',
      description='Python package for Financial Analytics!',
      url='https://github.com/my13/fa_mbd_2015b',
      author='TEAM B - Master Big Data',
      author_email='jldelgadodavara@student.ie.edu',
      license='MIT',
      packages=['fambd2015b'],
      zip_safe=False)