from .safechars import safe_upperstr
from .safechars import safe_chars_nombrepersona
from .safechars import safe_upperstr_razonsocial


def imprime():
	return 3

def sumados(valor):
	return valor+2

