def safechars():
	return 1

def imprime():
	return 2

def sumauno(valor):
	return valor+1

